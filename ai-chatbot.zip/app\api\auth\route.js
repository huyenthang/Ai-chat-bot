import { NextResponse } from 'next/server'

export async function POST(request) {
  try {
    const { password } = await request.json()
    
    if (!password) {
      return NextResponse.json({ success: false, error: 'Password required' })
    }
    
    // Get password from environment variable
    const correctPassword = process.env.CHAT_PASSWORD
    
    if (password === correctPassword) {
      return NextResponse.json({ success: true })
    } else {
      return NextResponse.json({ success: false, error: 'Invalid password' })
    }
    
  } catch (error) {
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
  }
}