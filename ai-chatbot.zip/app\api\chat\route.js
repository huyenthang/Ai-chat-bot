import { NextResponse } from 'next/server'

export async function POST(request) {
  try {
    const { message } = await request.json()
    
    if (!message) {
      return NextResponse.json({ error: 'Message is required' }, { status: 400 })
    }
    
    // Get API key from environment variable - SECURED!
    const apiKey = process.env.OPENAI_API_KEY
    
    if (!apiKey || apiKey === 'sk-your-openai-api-key-here') {
      return NextResponse.json({ 
        error: 'API key chưa được cấu hình. Vui lòng thêm OPENAI_API_KEY trong biến môi trường.' 
      }, { status: 500 })
    }
    
    // System prompt to restrict to AI/AI Agent topics only
    const systemPrompt = `Bạn là một AI Assistant chuyên về AI (Trí tuệ nhân tạo) và AI Agent. 
Nhiệm vụ của bạn:
1. Trả lời các câu hỏi về AI, Machine Learning, Deep Learning, AI Agent
2. Nếu người dùng hỏi về chủ đề KHÔNG liên quan đến AI hoặc AI Agent, hãy trả lời lịch sự:
"Tôi chỉ hỗ trợ các câu hỏi về AI và AI Agent. Xin lỗi, tôi không thể giúp bạn với chủ đề này."

Hãy trả lời ngắn gọn, dễ hiểu, bằng tiếng Việt.`

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: message }
        ],
        temperature: 0.7,
        max_tokens: 500
      })
    })

    if (!response.ok) {
      const errorData = await response.json()
      return NextResponse.json({ 
        error: errorData.error?.message || 'Lỗi API' 
      }, { status: 500 })
    }

    const data = await response.json()
    const aiResponse = data.choices[0]?.message?.content || 'Không có phản hồi'
    
    return NextResponse.json({ 
      response: aiResponse,
      timestamp: new Date().toISOString()
    })
    
  } catch (error) {
    return NextResponse.json({ error: 'Lỗi server: ' + error.message }, { status: 500 })
  }
}