import './globals.css'

export const metadata = {
  title: 'AI Agent Chatbot',
  description: 'Chatbot for AI and AI Agent questions',
}

export default function RootLayout({ children }) {
  return (
    <html lang="vi">
      <body>{children}</body>
    </html>
  )
}