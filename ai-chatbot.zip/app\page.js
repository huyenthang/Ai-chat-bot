'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'

export default function Home() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [password, setPassword] = useState('')
  const [message, setMessage] = useState('')
  const [chatHistory, setChatHistory] = useState([])
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  useEffect(() => {
    const auth = localStorage.getItem('chat_auth')
    if (auth === 'true') {
      setIsAuthenticated(true)
    }
  }, [])

  const handleLogin = async (e) => {
    e.preventDefault()
    
    try {
      const res = await fetch('/api/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password })
      })
      
      const data = await res.json()
      
      if (data.success) {
        localStorage.setItem('chat_auth', 'true')
        setIsAuthenticated(true)
      } else {
        alert('Mật khẩu không đúng!')
      }
    } catch (error) {
      alert('Lỗi xác thực!')
    }
  }

  const handleLogout = () => {
    localStorage.removeItem('chat_auth')
    setIsAuthenticated(false)
    setPassword('')
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!message.trim() || isLoading) return

    const userMessage = message
    setMessage('')
    setChatHistory(prev => [...prev, { role: 'user', content: userMessage }])
    setIsLoading(true)

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: userMessage })
      })

      const data = await res.json()
      
      if (data.response) {
        setChatHistory(prev => [...prev, { role: 'assistant', content: data.response }])
      } else if (data.error) {
        setChatHistory(prev => [...prev, { role: 'assistant', content: 'Đã xảy ra lỗi: ' + data.error }])
      }
    } catch (error) {
      setChatHistory(prev => [...prev, { role: 'assistant', content: 'Đã xảy ra lỗi. Vui lòng thử lại.' }])
    }

    setIsLoading(false)
  }

  // Login Screen
  if (!isAuthenticated) {
    return (
      <div className="login-container">
        <div className="login-box">
          <h1>🤖 AI Agent Chatbot</h1>
          <p>Nhập mật khẩu để tiếp tục</p>
          <form onSubmit={handleLogin}>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Nhập mật khẩu..."
              required
            />
            <button type="submit">Vào Chat</button>
          </form>
        </div>
      </div>
    )
  }

  // Chat Screen
  return (
    <div className="chat-container">
      <div className="chat-header">
        <h1>🤖 AI Agent Chatbot</h1>
        <button onClick={handleLogout} className="logout-btn">Đăng xuất</button>
      </div>

      <div className="chat-messages">
        {chatHistory.length === 0 && (
          <div className="welcome-message">
            Xin chào! Tôi là AI Agent Chatbot. Bạn có thể hỏi tôi về:
            <ul>
              <li>AI (Trí tuệ nhân tạo)</li>
              <li>AI Agent</li>
              <li>Machine Learning</li>
              <li>Deep Learning</li>
              <li>Các công nghệ AI khác</li>
            </ul>
          </div>
        )}
        {chatHistory.map((msg, index) => (
          <div key={index} className={`message ${msg.role === 'user' ? 'message-user' : 'message-assistant'}`}>
            {msg.content}
          </div>
        ))}
        {isLoading && <div className="typing">...</div>}
      </div>

      <form onSubmit={handleSubmit} className="chat-input">
        <input
          type="text"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Hỏi về AI hoặc AI Agent..."
          disabled={isLoading}
        />
        <button type="submit" disabled={isLoading || !message.trim()}>Gửi</button>
      </form>
    </div>
  )
}